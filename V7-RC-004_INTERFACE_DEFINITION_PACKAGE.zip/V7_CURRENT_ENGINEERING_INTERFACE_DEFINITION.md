# V7 CURRENT ENGINEERING INTERFACE DEFINITION — RC-004

## Boundary
This artifact is a **CURRENT ENGINEERING DESIGN DEFINITION**. It is not a historical/source-evidence rewrite and it is not physical validation.

The nine geometric overlaps remain the nine source-overlap records from V7-RC-004. Their exact intersection volumes and face IDs are preserved. fileciteturn69file0L10-L61 fileciteturn69file0L63-L110 fileciteturn69file0L113-L175 fileciteturn69file0L177-L240 fileciteturn69file0L242-L303 fileciteturn69file0L305-L366 fileciteturn69file0L368-L421 fileciteturn69file0L423-L472 fileciteturn69file0L474-L529

## Design-intent conclusion
**9/9 interfaces have a controlled CURRENT ENGINEERING DESIGN INTENT.** This does not mean 9/9 physical interfaces are validated.

The current model defines the 2-DOF mechanism as q1 carriage translation and q2 seatback rotation. It explicitly maps J_LINK_L from 150L to 160 as a q2-coupled REVOLUTE_LINK and J_SEATBACK from J to 160 as a REVOLUTE joint about [0,1,0]. fileciteturn71file0L22-L134

The model defines 120 as the carriage, 130L/130R as carriage-coupled ride-down modules, 140 as fixed-with-carriage pelvic-control, 150L/150R as q2-coupled links, 160 as q2 rotation, 170/180 as state-dependent mechanisms, and 200 as carriage-coupled guidance. fileciteturn71file4L337-L417

The state machine defines NORMAL/ARMED/RIDE_DOWN/REBOUND_CONTROL/SECURE, with q1 allowed in ride-down, reverse-controlled q1 during rebound, and no allowed DOF in secure. Transition timing is explicitly undefined. fileciteturn71file1L150-L223

## What is NOT proven
- No interface is physically validated.
- No fastener, preload, friction, contact law, or material value is promoted.
- No manufacturing tolerance is invented.
- Exact mating surface semantics remain source-release pending where the B-rep only identifies candidate face sets.
- 170 and 180 remain model/state representations, not hardware validation. fileciteturn69file1L543-L563

## Interface matrix

| ID | Pair | Current design intent | Type | Model relation |
|---|---|---|---|---|
| IF-R4-01 | 120 ↔ 130L | Left absorber structural/load-transfer interface | STRUCTURAL_INTERFACE | carriage-coupled |
| IF-R4-02 | 120 ↔ 130R | Right absorber structural/load-transfer interface | STRUCTURAL_INTERFACE | carriage-coupled |
| IF-R4-03 | 120 ↔ 140 | Carriage-supported pelvic-control interface | STRUCTURAL_INTERFACE | carriage-coupled |
| IF-R4-04 | 120 ↔ 200 | Carriage/occupant-guidance interface | GUIDED_INTERFACE | carriage-coupled |
| IF-R4-05 | 130L ↔ 140 | Left energy-management/pelvic-control structural interface | STRUCTURAL_INTERFACE | carriage-coupled |
| IF-R4-06 | 130R ↔ 140 | Right energy-management/pelvic-control structural interface | STRUCTURAL_INTERFACE | carriage-coupled |
| IF-R4-07 | 140 ↔ 160 | Pelvic-control/seatback structural interface | STRUCTURAL_INTERFACE | constrained by q1/q2 system |
| IF-R4-08 | 150L ↔ 160 | Left rotation-control link joint | JOINT | q2-coupled |
| IF-R4-09 | 160 ↔ J | Seatback hinge joint | JOINT | q2 revolute |

## Baseline protection
No V7-R3, R4.1, or CAD geometry was modified. No R4.2 was created. Geometry change proposals = none.

## Status
`CURRENT_ENGINEERING_DEFINITION = COMPLETE`

The definition is complete at **current design-intent/model level**. It is not a manufacturing release and does not close physical validation.
