# P0_PROTOTYPE_PARAMETER_PACK

Generated: 2026-09-07T04:17:47.373730+03:00

## Evidence boundary

This is V5/V7 forensic extraction and engineering-definition material only. V5 explicitly labels the nominal envelope as concept assumptions; V7 explicitly states that 180 mm and 18–22 kN are design-target/source values, not T-OCS measurements. fileciteturn24file0L1-L12 fileciteturn24file7L1-L8

## 14-input master matrix

|ID|Quantity|Unit|CAD derivable|Status|Canonical file|
|---|---|---|---|---|---|
|PI-01|mass|kg|YES|CAD_DERIVABLE|`mass_properties.json`|
|PI-02|CG|m|YES|CAD_DERIVABLE|`cg_properties.json`|
|PI-03|full inertia tensor about CG|kg·m²|YES|CAD_DERIVABLE|`inertia_tensor.json`|
|PI-04|density per material region/lot|kg/m³|NO|EXTERNAL_SOURCE_REQUIRED|`material_density.json`|
|PI-05|vehicle/seat-base acceleration time history|m/s² vs s|NO|EXTERNAL_SOURCE_REQUIRED|`vehicle_pulse.json`|
|PI-06|initial velocity vector at t0|m/s|NO|EXTERNAL_SOURCE_REQUIRED|`initial_velocity.json`|
|PI-07|configuration-specific bolt/joint stiffness|N/m|NO|PHYSICAL_TEST_REQUIRED|`bolt_stiffness.json`|
|PI-08|interface-specific friction law|dimensionless|NO|PHYSICAL_TEST_REQUIRED|`friction.json`|
|PI-09|normal contact stiffness law|N/m|NO|PHYSICAL_TEST_REQUIRED|`contact_stiffness.json`|
|PI-10|normal contact damping law|N·s/m or explicit constitutive form|NO|PHYSICAL_TEST_REQUIRED|`contact_damping.json`|
|PI-11|restitution coefficient/law|dimensionless|NO|PHYSICAL_TEST_REQUIRED|`restitution.json`|
|PI-12|absorber force-displacement F(x)|N vs m|NO|PHYSICAL_TEST_REQUIRED|`absorber_Fx.json`|
|PI-13|absorber rate-dependent F(x,v,T) / F-v map|N vs m/s|NO|PHYSICAL_TEST_REQUIRED|`absorber_Fv.json`|
|PI-14|joint compliance/stiffness law|m/N and/or rad/(N·m), or declared matrix|NO|PHYSICAL_TEST_REQUIRED|`joint_compliance.json`|

## Per-input engineering definition

### PI-01 — mass
- R4.1 target: R4.1 exact article/configuration
- Frame/sign: Interface/local frame as specified / Scalar; exact configuration defined
- Loading/configuration: Exact documented configuration and operating condition; no generic value / R4.1 geometry/material map
- Source/test route: CAD derivation possible only with authoritative material mapping
- CAD derivable: YES
- Minimum method: CAD derivation possible only with authoritative material mapping; otherwise calibrated weighing
- Evidence: Traceable artifact for mass; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `mass_properties.json`
- Status: **CAD_DERIVABLE**

### PI-02 — CG
- R4.1 target: R4.1 native frame
- Frame/sign: R4.1 native engineering frame / +X FWD, +Y LEFT, +Z UP only where source frame establishes this
- Loading/configuration: Exact documented configuration and operating condition; no generic value / R4.1 native datum
- Source/test route: CAD first-moment derivation possible only with authoritative mass/material mapping
- CAD derivable: YES
- Minimum method: CAD first-moment derivation possible only with authoritative mass/material mapping; otherwise calibrated reaction/balance measurement
- Evidence: Traceable artifact for CG; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `cg_properties.json`
- Status: **CAD_DERIVABLE**

### PI-03 — full inertia tensor about CG
- R4.1 target: R4.1 native axes, origin at CG
- Frame/sign: R4.1 native engineering frame / Symmetric 3×3 tensor with declared product-of-inertia convention
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Exact rigid article configuration
- Source/test route: CAD possible conditionally
- CAD derivable: YES
- Minimum method: CAD possible conditionally; otherwise rotational inertia fixture with fixture subtraction
- Evidence: Traceable artifact for full inertia tensor about CG; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `inertia_tensor.json`
- Status: **CAD_DERIVABLE**

### PI-04 — density per material region/lot
- R4.1 target: Every material region actually used
- Frame/sign: Interface/local frame as specified / Positive scalar
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Material characterization condition; temperature recorded
- Source/test route: MTR/CoC or calibrated density test for actual lot
- CAD derivable: NO
- Minimum method: MTR/CoC or calibrated density test for actual lot
- Evidence: Traceable artifact for density per material region/lot; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `material_density.json`
- Status: **EXTERNAL_SOURCE_REQUIRED**

### PI-05 — vehicle/seat-base acceleration time history
- R4.1 target: Vehicle/fixture interface load path
- Frame/sign: R4.1 native engineering frame / Transform source axes into registered R4.1 frame; retain source sign convention
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Defined crash/sled event and channel
- Source/test route: Qualified external vehicle/sled data acquisition
- CAD derivable: NO
- Minimum method: Qualified external vehicle/sled data acquisition
- Evidence: Traceable artifact for vehicle/seat-base acceleration time history; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `vehicle_pulse.json`
- Status: **EXTERNAL_SOURCE_REQUIRED**

### PI-06 — initial velocity vector at t0
- R4.1 target: Declared model/test boundary
- Frame/sign: R4.1 native engineering frame / Vector components follow registered frame
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Exact event initial condition before first interaction
- Source/test route: Qualified independent speed/velocity measurement
- CAD derivable: NO
- Minimum method: Qualified independent speed/velocity measurement
- Evidence: Traceable artifact for initial velocity vector at t0; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `initial_velocity.json`
- Status: **EXTERNAL_SOURCE_REQUIRED**

### PI-07 — configuration-specific bolt/joint stiffness
- R4.1 target: Each modeled fastener/joint stack
- Frame/sign: Interface/local frame as specified / Positive extension/separation convention; local fastener axis
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Exact grade/size/grip/preload/torque/washer/nut stack
- Source/test route: Instrumented joint/fastener characterization
- CAD derivable: NO
- Minimum method: Instrumented joint/fastener characterization
- Evidence: Traceable artifact for configuration-specific bolt/joint stiffness; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `bolt_stiffness.json`
- Status: **PHYSICAL_TEST_REQUIRED**

### PI-08 — interface-specific friction law
- R4.1 target: Each modeled sliding/contact pair
- Frame/sign: Interface/local frame as specified / Positive normal compression; tangential sign follows motion
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Surface/material/lubrication/temperature/normal load/velocity
- Source/test route: Controlled interface sliding test
- CAD derivable: NO
- Minimum method: Controlled interface sliding test
- Evidence: Traceable artifact for interface-specific friction law; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `friction.json`
- Status: **PHYSICAL_TEST_REQUIRED**

### PI-09 — normal contact stiffness law
- R4.1 target: Each modeled stop/contact pair
- Frame/sign: Interface/local frame as specified / Local contact-normal convention
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Exact contact geometry/material/temperature
- Source/test route: Controlled compression/impact F-x identification
- CAD derivable: NO
- Minimum method: Controlled compression/impact F-x identification
- Evidence: Traceable artifact for normal contact stiffness law; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `contact_stiffness.json`
- Status: **PHYSICAL_TEST_REQUIRED**

### PI-10 — normal contact damping law
- R4.1 target: Each transient contact pair where modeled
- Frame/sign: Interface/local frame as specified / Local normal approach/rebound convention
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Exact interface, temperature and impact condition
- Source/test route: Repeated controlled impact with F-x-v-t data
- CAD derivable: NO
- Minimum method: Repeated controlled impact with F-x-v-t data
- Evidence: Traceable artifact for normal contact damping law; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `contact_damping.json`
- Status: **PHYSICAL_TEST_REQUIRED**

### PI-11 — restitution coefficient/law
- R4.1 target: Only interfaces with real rebound/impact
- Frame/sign: Interface/local frame as specified / Approach/rebound normal-velocity ratio with stated sign convention
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Isolated impact; no secondary contact
- Source/test route: High-speed x(t)/velocity + force + synchronized video where needed
- CAD derivable: NO
- Minimum method: High-speed x(t)/velocity + force + synchronized video where needed
- Evidence: Traceable artifact for restitution coefficient/law; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `restitution.json`
- Status: **PHYSICAL_TEST_REQUIRED**

### PI-12 — absorber force-displacement F(x)
- R4.1 target: Each 130 cartridge, left/right/configuration-specific
- Frame/sign: Interface/local frame as specified / Positive resisting force along absorber axis
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Exact cartridge serial, mounting, alignment, temperature, preconditioning
- Source/test route: Quasi-static/controlled-dynamic cartridge test
- CAD derivable: NO
- Minimum method: Quasi-static/controlled-dynamic cartridge test
- Evidence: Traceable artifact for absorber force-displacement F(x); exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `absorber_Fx.json`
- Status: **PHYSICAL_TEST_REQUIRED**

### PI-13 — absorber rate-dependent F(x,v,T) / F-v map
- R4.1 target: 130 cartridge operating domain
- Frame/sign: Interface/local frame as specified / Positive resisting force and stroke velocity along absorber axis
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Exact cartridge/configuration + temperature
- Source/test route: Dynamic rate sweep using calibrated force/displacement/temperature
- CAD derivable: NO
- Minimum method: Dynamic rate sweep using calibrated force/displacement/temperature
- Evidence: Traceable artifact for absorber rate-dependent F(x,v,T) / F-v map; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `absorber_Fv.json`
- Status: **PHYSICAL_TEST_REQUIRED**

### PI-14 — joint compliance/stiffness law
- R4.1 target: 150L/150R, 160 hinge, relevant compliant joints
- Frame/sign: Interface/local frame as specified / Local joint generalized coordinates/loads
- Loading/configuration: Exact documented configuration and operating condition; no generic value / Exact bushing/pin/fastener/preload/lubrication/clearance
- Source/test route: Bidirectional force/moment vs displacement/angle characterization
- CAD derivable: NO
- Minimum method: Bidirectional force/moment vs displacement/angle characterization
- Evidence: Traceable artifact for joint compliance/stiffness law; exact configuration, source/procedure revision, calibration, raw data, reduction and SHA-256
- Raw data: Raw immutable data + CSV export + metadata JSON
- Identification: Configuration-specific reduction within measured/source domain; no extrapolation without explicit model disclosure
- Uncertainty: Report measurement/source uncertainty and repeatability; preserve processing basis
- Acceptance: Manus accepts only with complete provenance and unambiguous configuration mapping
- Manus file: `joint_compliance.json`
- Status: **PHYSICAL_TEST_REQUIRED**

## Extracted numerical values

The source set contains design/reference/study values, not a validated T-OCS physical dataset. The extracted values include 500, 520, 860 mm; 25°; 180 mm; 210 mm; -10…+25°; 520/560/1120 mm; 25.6 g; 18–22 kN; 25–35 kN; -40…+80 °C; 56 km/h; 53.9 km/h; 373 N·m; and the illustrative 75 kg, 15.6 m/s, 9.1 kJ example. fileciteturn23file4L1-L22 fileciteturn24file0L1-L12

## Relationships

Extracted engineering relationships: **16**. V5 defines T0–T6 sequencing; numeric transition times are not stated. fileciteturn24file0L1-L7

## CAD-derivable candidates

Mass, CG and inertia are legitimately CAD-derivable only conditionally, after exact configuration and authoritative material-density mapping. The P0 master states that physical mass/CG/inertia measurement is the evidence bridge and CAD is not automatically physical evidence. fileciteturn24file11L1-L15

## Negative register
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: physical T-OCS mass measurement
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: physical T-OCS CG measurement
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: physical T-OCS inertia measurement
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated density mapping for every used material lot
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated interface-specific friction
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated contact stiffness
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated contact damping
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated restitution
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: measured absorber F-x
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: measured absorber F-v/rate law
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated T-OCS vehicle pulse
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated T-OCS initial velocity
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated joint compliance
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated bolt/joint stiffness
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: released vehicle production hardpoints
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: released GD&T
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: released manufacturing BOM/final lot mapping
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated restraint anchorage loads
- NOT FOUND AS VALIDATED PHYSICAL EVIDENCE: validated Lock/trigger fault evidence

## P0 priority

P0-A: mass, CG, inertia, density. P0-B: friction, contact stiffness, contact damping, restitution. P0-C: absorber F-x/F-v. P0-D: bolt stiffness, joint compliance, vehicle pulse, initial velocity. P0-E: reference/study/regulatory material.

## Traceability

`ORIGINAL DESIGN → V5/V7 SOURCE → R4.1 ELEMENT → PHYSICAL INPUT → RAW EVIDENCE → REDUCTION → SHA256/PROVENANCE → Manus VALIDATOR → FUTURE MBD/FE`

The P0 test matrix specifies calibration traceability, raw-data preservation, uncertainty, configuration identity and interface-specific tests for friction, contact stiffness/damping, restitution, absorber F-x/F-v and joint/fastener stiffness/compliance. fileciteturn23file9L1-L8 fileciteturn24file15L1-L10

## Final status

`P0_PROTOTYPE_PARAMETER_PACK = PARTIAL`

`V5_EXTRACTION = PARTIAL`

`V7_EXTRACTION = PARTIAL`

`V5_V7_DELTA = PASS`

`TRACEABILITY = PARTIAL`

`PHYSICAL_RESULT_INTEGRITY = PASS`

`FALSE_MEASUREMENT_PROMOTION = 0`

Reason: the source material is sufficient to define the engineering requirements and preserve the evidence firewall, but not to supply the 14 physical values as validated evidence.